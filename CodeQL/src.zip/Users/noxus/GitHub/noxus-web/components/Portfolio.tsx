const Portfolio = () => {
  return (
    <div
      data-property-1="Off"
      className="self-stretch h-[2110.66px] px-28 py-20 relative bg-neutral-950 inline-flex flex-col justify-start items-center gap-10"
    >
      <div className="w-96 h-56 left-[1137px] top-[957px] absolute opacity-80 bg-red-800 rounded-full blur-[333px]" />
      <div className="size- inline-flex justify-start items-start gap-5">
        <div
          data-icon="false"
          data-size="Small"
          data-status="Selected"
          className="h-9 inline-flex flex-col justify-center items-center"
        >
          <div className="flex-1 py-4 flex flex-col justify-center items-center gap-2.5">
            <div className="justify-center text-red-800 text-sm font-normal font-['Satoshi_Variable'] leading-tight">
              All Projects
            </div>
          </div>
          <div className="self-stretch h-0 border-2 border-red-800"></div>
        </div>
        <div
          data-icon="false"
          data-size="Small"
          data-status="Normal"
          className="h-9 flex justify-center items-center overflow-hidden"
        >
          <div className="self-stretch py-4 inline-flex flex-col justify-center items-center gap-2.5">
            <div className="justify-center text-white/70 text-sm font-normal font-['Satoshi_Variable'] leading-tight">
              Finance
            </div>
          </div>
        </div>
        <div
          data-icon="false"
          data-size="Small"
          data-status="Normal"
          className="h-9 flex justify-center items-center overflow-hidden"
        >
          <div className="self-stretch py-4 inline-flex flex-col justify-center items-center gap-2.5">
            <div className="justify-center text-white/70 text-sm font-normal font-['Satoshi_Variable'] leading-tight">
              E-Commerce
            </div>
          </div>
        </div>
        <div
          data-icon="false"
          data-size="Small"
          data-status="Normal"
          className="h-9 flex justify-center items-center overflow-hidden"
        >
          <div className="self-stretch py-4 inline-flex flex-col justify-center items-center gap-2.5">
            <div className="justify-center text-white/70 text-sm font-normal font-['Satoshi_Variable'] leading-tight">
              Government
            </div>
          </div>
        </div>
        <div
          data-icon="false"
          data-size="Small"
          data-status="Normal"
          className="h-9 flex justify-center items-center overflow-hidden"
        >
          <div className="self-stretch py-4 inline-flex flex-col justify-center items-center gap-2.5">
            <div className="justify-center text-white/70 text-sm font-normal font-['Satoshi_Variable'] leading-tight">
              Tech
            </div>
          </div>
        </div>
      </div>
      <div
        data-property-1="Default"
        className="w-[1200px] h-[500px] rounded-[30px] outline outline-1 outline-offset-[-1px] outline-white/10 flex flex-col justify-start items-start overflow-hidden"
      >
        <img
          className="self-stretch flex-1 rounded-[20px]"
          src="https://placehold.co/1200x500"
        />
        <div className="self-stretch h-28 px-4 py-3 bg-stone-900/40 backdrop-blur-xl flex flex-col justify-center items-start gap-2">
          <div className="self-stretch justify-center text-white text-xl font-bold font-['Satoshi_Variable'] leading-7">
            BRISMA - Bank BRI Management Audit System
          </div>
          <div className="self-stretch justify-center text-white text-sm font-normal font-['Satoshi_Variable'] leading-tight">
            Management Audit
          </div>
        </div>
      </div>
      <div
        data-property-1="Default"
        className="w-[1200px] h-[500px] rounded-[30px] outline outline-1 outline-offset-[-1px] outline-white/10 flex flex-col justify-start items-start overflow-hidden"
      >
        <img
          className="self-stretch flex-1 rounded-[20px]"
          src="https://placehold.co/1200x500"
        />
        <div className="self-stretch h-28 px-4 py-3 bg-stone-900/40 backdrop-blur-xl flex flex-col justify-center items-start gap-2">
          <div className="self-stretch justify-center text-white text-xl font-bold font-['Satoshi_Variable'] leading-7">
            BRISMA - Bank BRI Management Audit System
          </div>
          <div className="self-stretch justify-center text-white text-sm font-normal font-['Satoshi_Variable'] leading-tight">
            Management Audit
          </div>
        </div>
      </div>
      <div className="self-stretch inline-flex justify-center items-start gap-10 flex-wrap content-start">
        <div
          data-property-1="Default"
          className="flex-1 h-96 max-w-96 min-w-96 rounded-[30px] outline outline-1 outline-offset-[-1px] outline-white/10 inline-flex flex-col justify-start items-start overflow-hidden"
        >
          <img
            className="self-stretch flex-1 rounded-[20px]"
            src="https://placehold.co/373x373"
          />
          <div className="self-stretch h-28 px-4 py-3 bg-stone-900/40 backdrop-blur-xl flex flex-col justify-center items-start gap-2">
            <div className="self-stretch justify-center text-white text-xl font-bold font-['Satoshi_Variable'] leading-7">
              BRISMA - Bank BRI Management Audit System
            </div>
            <div className="self-stretch justify-center text-white text-sm font-normal font-['Satoshi_Variable'] leading-tight">
              Management Audit
            </div>
          </div>
        </div>
        <div
          data-property-1="Default"
          className="flex-1 h-96 max-w-96 min-w-96 rounded-[30px] outline outline-1 outline-offset-[-1px] outline-white/10 inline-flex flex-col justify-start items-start overflow-hidden"
        >
          <img
            className="self-stretch flex-1 rounded-[20px]"
            src="https://placehold.co/373x373"
          />
          <div className="self-stretch h-28 px-4 py-3 bg-stone-900/40 backdrop-blur-xl flex flex-col justify-center items-start gap-2">
            <div className="self-stretch justify-center text-white text-xl font-bold font-['Satoshi_Variable'] leading-7">
              BRISMA - Bank BRI Management Audit System
            </div>
            <div className="self-stretch justify-center text-white text-sm font-normal font-['Satoshi_Variable'] leading-tight">
              Management Audit
            </div>
          </div>
        </div>
        <div
          data-property-1="Default"
          className="flex-1 h-96 max-w-96 min-w-96 rounded-[30px] outline outline-1 outline-offset-[-1px] outline-white/10 inline-flex flex-col justify-start items-start overflow-hidden"
        >
          <img
            className="self-stretch flex-1 rounded-[20px]"
            src="https://placehold.co/373x373"
          />
          <div className="self-stretch h-28 px-4 py-3 bg-stone-900/40 backdrop-blur-xl flex flex-col justify-center items-start gap-2">
            <div className="self-stretch justify-center text-white text-xl font-bold font-['Satoshi_Variable'] leading-7">
              BRISMA - Bank BRI Management Audit System
            </div>
            <div className="self-stretch justify-center text-white text-sm font-normal font-['Satoshi_Variable'] leading-tight">
              Management Audit
            </div>
          </div>
        </div>
        <div
          data-property-1="Default"
          className="flex-1 h-96 max-w-96 min-w-96 rounded-[30px] outline outline-1 outline-offset-[-1px] outline-white/10 inline-flex flex-col justify-start items-start overflow-hidden"
        >
          <img
            className="self-stretch flex-1 rounded-[20px]"
            src="https://placehold.co/373x373"
          />
          <div className="self-stretch h-28 px-4 py-3 bg-stone-900/40 backdrop-blur-xl flex flex-col justify-center items-start gap-2">
            <div className="self-stretch justify-center text-white text-xl font-bold font-['Satoshi_Variable'] leading-7">
              BRISMA - Bank BRI Management Audit System
            </div>
            <div className="self-stretch justify-center text-white text-sm font-normal font-['Satoshi_Variable'] leading-tight">
              Management Audit
            </div>
          </div>
        </div>
        <div
          data-property-1="Default"
          className="flex-1 h-96 max-w-96 min-w-96 rounded-[30px] outline outline-1 outline-offset-[-1px] outline-white/10 inline-flex flex-col justify-start items-start overflow-hidden"
        >
          <img
            className="self-stretch flex-1 rounded-[20px]"
            src="https://placehold.co/373x373"
          />
          <div className="self-stretch h-28 px-4 py-3 bg-stone-900/40 backdrop-blur-xl flex flex-col justify-center items-start gap-2">
            <div className="self-stretch justify-center text-white text-xl font-bold font-['Satoshi_Variable'] leading-7">
              BRISMA - Bank BRI Management Audit System
            </div>
            <div className="self-stretch justify-center text-white text-sm font-normal font-['Satoshi_Variable'] leading-tight">
              Management Audit
            </div>
          </div>
        </div>
        <div
          data-property-1="Default"
          className="flex-1 h-96 max-w-96 min-w-96 rounded-[30px] outline outline-1 outline-offset-[-1px] outline-white/10 inline-flex flex-col justify-start items-start overflow-hidden"
        >
          <img
            className="self-stretch flex-1 rounded-[20px]"
            src="https://placehold.co/373x373"
          />
          <div className="self-stretch h-28 px-4 py-3 bg-stone-900/40 backdrop-blur-xl flex flex-col justify-center items-start gap-2">
            <div className="self-stretch justify-center text-white text-xl font-bold font-['Satoshi_Variable'] leading-7">
              BRISMA - Bank BRI Management Audit System
            </div>
            <div className="self-stretch justify-center text-white text-sm font-normal font-['Satoshi_Variable'] leading-tight">
              Management Audit
            </div>
          </div>
        </div>
      </div>
      <div
        data-icon="None"
        data-size="Large"
        data-state="Default"
        className="h-11 min-w-28 p-2 rounded-sm outline outline-1 outline-offset-[-1px] outline-white flex flex-col justify-center items-center"
      >
        <div className="text-center justify-start text-white text-base font-normal font-['Satoshi_Variable'] leading-normal">
          Load More
        </div>
      </div>
    </div>
  )
}

export default Portfolio
